const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');
const cors = require('cors');
require('dotenv').config();

require('./config/database');

const authRoutes = require('./routes/authRoutes');
const keyRoutes = require('./routes/keyRoutes');
const cableRoutes = require('./routes/cableRoutes');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });

// Trust proxy untuk membaca IP Address global pembeli secara akurat
app.set('trust proxy', true);

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/api/auth', authRoutes);
app.use('/api/keys', keyRoutes);
app.use('/api/cable', cableRoutes);

// Socket Signal Pipeline
io.on('connection', (socket) => {
    socket.on('attach_cable', (pipeId) => {
        socket.join(pipeId);
        console.log(`[KEPENG Cable] Channel aktif global: ${pipeId}`);
    });

    socket.on('send_payment_signal', (payload) => {
        console.log(`[KEPENG Signal] Sinyal lunas dipancarkan: ${payload.pipe_id}`);
        io.to(payload.pipe_id).emit('payment_routed_success', {
            status: 'COMPLETED',
            paid_amount: payload.final_amount,
            currency: payload.buyer_currency,
            country: payload.buyer_country,
            method: payload.method,
            timestamp: new Date().toISOString()
        });
    });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
    console.log(`====================================================`);
    console.log(`🚀 KEPENG Global Auto-FX Engine Aktif di http://localhost:${PORT}`);
    console.log(`====================================================`);
});
