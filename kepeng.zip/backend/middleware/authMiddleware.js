const db = require('../config/database');

module.exports = (req, res, next) => {
    const apiKey = req.headers['x-api-key'] || req.body.api_key || req.query.api_key;

    if (!apiKey) {
        return res.status(401).json({ success: false, error: 'API Key wajib disertakan!' });
    }

    db.get(`SELECT merchant_id FROM api_keys WHERE public_key = ? OR secret_key = ?`, [apiKey, apiKey], (err, row) => {
        if (err || !row) {
            return res.status(401).json({ success: false, error: 'API Key tidak valid atau tidak terdaftar!' });
        }
        req.merchantId = row.merchant_id;
        next();
    });
};
