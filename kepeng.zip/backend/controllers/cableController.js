const db = require('../config/database');
const axios = require('axios');
const crypto = require('crypto');

const activePipes = {};

// Helper: Deteksi Mata Uang Otomatis Berdasarkan IP Negara Pembeli
async function detectBuyerCurrencyAndCountry(clientIp) {
    try {
        // Bebas API Key, otomatis mendeteksi negara & mata uang lokal pembeli
        const res = await axios.get(`http://ip-api.com/json/${clientIp}?fields=status,country,countryCode,currency`);
        if (res.data && res.data.status === 'success' && res.data.currency) {
            return {
                currency: res.data.currency,
                country: res.data.country,
                countryCode: res.data.countryCode
            };
        }
    } catch (err) {
        console.log("IP Auto-Detection fallback to USD/Global");
    }
    // Default fallback jika pengujian di localhost / IP lokal
    return { currency: 'USD', country: 'Global / International', countryCode: 'US' };
}

// Helper: Global Live Exchange Rate Oracle (Mendukung Seluruh Mata Uang Dunia)
async function getGlobalExchangeRate(fromCurr, toCurr) {
    if (fromCurr.toUpperCase() === toCurr.toUpperCase()) return 1;
    try {
        const res = await axios.get(`https://open.er-api.com/v6/latest/${fromCurr.toUpperCase()}`);
        return res.data.rates[toCurr.toUpperCase()] || 1;
    } catch (err) {
        console.error("FX Oracle Error:", err.message);
        return 1;
    }
}

exports.initiatePipe = (req, res) => {
    const { api_key, amount, currency, recipient_account } = req.body;

    db.get(`SELECT merchant_id FROM api_keys WHERE public_key = ?`, [api_key], (err, row) => {
        if (err || !row) {
            return res.status(401).json({ success: false, error: 'Publishable Key KEPENG tidak valid!' });
        }

        const pipeId = 'KPN-PIPE-' + crypto.randomBytes(6).toString('hex').toUpperCase();
        
        activePipes[pipeId] = {
            merchant_id: row.merchant_id,
            amount: parseFloat(amount),
            currency: (currency || 'IDR').toUpperCase(),
            recipient_account,
            status: 'PENDING'
        };

        db.run(
            `INSERT INTO transactions (pipe_id, merchant_id, amount, currency, recipient_account, status) VALUES (?, ?, ?, ?, ?, ?)`,
            [pipeId, row.merchant_id, amount, currency || 'IDR', recipient_account, 'PENDING']
        );

        res.json({
            success: true,
            pipe_id: pipeId,
            checkout_url: `/checkout.html?pipe_id=${pipeId}`
        });
    });
};

exports.resolvePipe = async (req, res) => {
    const pipe = activePipes[req.params.pipe_id];
    if (!pipe) return res.status(404).json({ success: false, error: 'Channel transaksi tidak ditemukan' });

    // Dapatkan IP Pembeli dari Request
    let clientIp = req.headers['x-forwarded-for'] || req.socket.remoteAddress || '';
    if (clientIp.includes(',')) clientIp = clientIp.split(',')[0].trim();

    // 1. OTOMATIS: Deteksi Negara & Mata Uang Pembeli
    const buyerGeo = await detectBuyerCurrencyAndCountry(clientIp);
    
    // Jika ada override query (misal untuk simulasi pengujian), utamakan geo otomatis
    const targetCurrency = req.query.override_currency || buyerGeo.currency;

    // 2. OTOMATIS: Hitung Konversi Kurs Real-Time dari Oracle Global
    const rate = await getGlobalExchangeRate(pipe.currency, targetCurrency);
    const convertedAmount = (pipe.amount * rate).toFixed(2);

    res.json({
        success: true,
        pipe_id: req.params.pipe_id,
        merchant_original: {
            amount: pipe.amount,
            currency: pipe.currency
        },
        buyer_auto_detected: {
            country: buyerGeo.country,
            countryCode: buyerGeo.countryCode,
            currency: targetCurrency,
            converted_amount: convertedAmount,
            formatted_price: `${convertedAmount} ${targetCurrency}`
        },
        exchange_rate: rate,
        recipient_account: pipe.recipient_account
    });
};
