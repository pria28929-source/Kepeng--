const db = require('../config/database');
const crypto = require('crypto');

exports.getMerchantKeys = (req, res) => {
    const { merchant_id } = req.params;
    db.get(`SELECT public_key, secret_key FROM api_keys WHERE merchant_id = ?`, [merchant_id], (err, row) => {
        if (err || !row) return res.status(404).json({ success: false, error: 'API Key tidak ditemukan' });
        res.json({ success: true, keys: { publicKey: row.public_key, secretKey: row.secret_key } });
    });
};

exports.rotateKeys = (req, res) => {
    const { merchant_id } = req.body;
    const newPubKey = 'kp_live_pk_' + crypto.randomBytes(12).toString('hex');
    const newSecKey = 'kp_live_sk_' + crypto.randomBytes(24).toString('hex');

    db.run(
        `UPDATE api_keys SET public_key = ?, secret_key = ? WHERE merchant_id = ?`,
        [newPubKey, newSecKey, merchant_id],
        function(err) {
            if (err) return res.status(500).json({ success: false, error: err.message });
            res.json({
                success: true,
                message: 'API Key berhasil diperbarui!',
                keys: { publicKey: newPubKey, secretKey: newSecKey }
            });
        }
    );
};
