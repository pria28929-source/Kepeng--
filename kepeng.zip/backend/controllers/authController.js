const db = require('../config/database');
const crypto = require('crypto');

function generateKeys() {
    return {
        publicKey: 'kp_live_pk_' + crypto.randomBytes(12).toString('hex'),
        secretKey: 'kp_live_sk_' + crypto.randomBytes(24).toString('hex')
    };
}

exports.registerMerchant = (req, res) => {
    const { name, email } = req.body;
    if (!name || !email) {
        return res.status(400).json({ success: false, error: 'Nama Toko dan Email wajib diisi!' });
    }

    const merchantId = 'MCH-' + Date.now().toString(36).toUpperCase();
    const keyId = 'KEY-' + Date.now().toString(36).toUpperCase();
    const keys = generateKeys();

    db.run(`INSERT INTO merchants (id, name, email) VALUES (?, ?, ?)`, [merchantId, name, email], function(err) {
        if (err) {
            return res.status(400).json({ success: false, error: 'Email sudah terdaftar!' });
        }

        db.run(
            `INSERT INTO api_keys (id, merchant_id, public_key, secret_key) VALUES (?, ?, ?, ?)`,
            [keyId, merchantId, keys.publicKey, keys.secretKey],
            function(err) {
                if (err) return res.status(500).json({ success: false, error: err.message });

                res.status(201).json({
                    success: true,
                    merchant: { id: merchantId, name, email, keys }
                });
            }
        );
    });
};
