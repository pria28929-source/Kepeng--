const express = require('express');
const router = express.Router();
const keyController = require('../controllers/keyController');

router.get('/:merchant_id', keyController.getMerchantKeys);
router.post('/rotate', keyController.rotateKeys);

module.exports = router;
