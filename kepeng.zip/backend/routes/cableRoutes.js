const express = require('express');
const router = express.Router();
const cableController = require('../controllers/cableController');

router.post('/initiate', cableController.initiatePipe);
router.get('/resolve/:pipe_id', cableController.resolvePipe);

module.exports = router;
