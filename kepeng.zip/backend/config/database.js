const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const dbPath = path.resolve(__dirname, '../kepeng.sqlite');
const db = new sqlite3.Database(dbPath);

db.serialize(() => {
    db.run(`
        CREATE TABLE IF NOT EXISTS merchants (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    `);

    db.run(`
        CREATE TABLE IF NOT EXISTS api_keys (
            id TEXT PRIMARY KEY,
            merchant_id TEXT NOT NULL,
            public_key TEXT UNIQUE NOT NULL,
            secret_key TEXT UNIQUE NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(merchant_id) REFERENCES merchants(id)
        )
    `);

    db.run(`
        CREATE TABLE IF NOT EXISTS transactions (
            pipe_id TEXT PRIMARY KEY,
            merchant_id TEXT NOT NULL,
            amount REAL NOT NULL,
            currency TEXT NOT NULL,
            recipient_account TEXT NOT NULL,
            status TEXT DEFAULT 'PENDING',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(merchant_id) REFERENCES merchants(id)
        )
    `);
});

module.exports = db;
