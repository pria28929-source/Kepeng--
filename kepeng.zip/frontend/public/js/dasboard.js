let currentMerchant = null;
const socket = io();

async function registerMerchant() {
    const name = document.getElementById('merchantName').value;
    const email = document.getElementById('merchantEmail').value;

    if (!name || !email) return alert("Mohon isi Nama Toko dan Email!");

    const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email })
    });

    const data = await res.json();
    if (data.success) {
        currentMerchant = data.merchant;
        renderDashboard();
    } else {
        alert(data.error);
    }
}

function renderDashboard() {
    document.getElementById('registerCard').classList.add('hidden');
    document.getElementById('dashboardConsole').classList.remove('hidden');

    document.getElementById('displayMerchantName').innerText = currentMerchant.name;
    document.getElementById('pubKeyDisplay').value = currentMerchant.keys.publicKey;
    document.getElementById('secKeyDisplay').value = currentMerchant.keys.secretKey;
}

async function testCableInitiation() {
    const apiKey = currentMerchant.keys.publicKey;
    const amount = document.getElementById('simAmount').value;
    const currency = document.getElementById('simCurrency').value;
    const recipient_account = document.getElementById('simAccount').value;

    const res = await fetch('/api/cable/initiate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ api_key: apiKey, amount, currency, recipient_account })
    });

    const data = await res.json();
    if (data.success) {
        const fullUrl = window.location.origin + data.checkout_url;
        document.getElementById('pipeResultBox').classList.remove('hidden');
        document.getElementById('generatedPipeUrl').value = fullUrl;
        document.getElementById('openCheckoutBtn').href = fullUrl;

        socket.emit('attach_cable', data.pipe_id);
        
        const monitor = document.getElementById('socketSignalStatus');
        monitor.innerText = "🔌 Kabel Aktif (" + data.pipe_id + "). Menunggu pembeli global menekan link...";
        monitor.className = "p-3 bg-slate-950 border border-amber-500/30 text-amber-400 rounded-lg text-xs font-mono font-bold";

        socket.on('payment_routed_success', (signal) => {
            monitor.innerText = `✅ SINYAL LUNAS DITERIMA! Transaksi: ${signal.paid_amount} (${signal.country}) via ${signal.method}`;
            monitor.className = "p-3 bg-slate-950 border border-emerald-500/50 text-emerald-400 rounded-lg text-xs font-mono font-bold";
        });
    }
}

function copyKey(elementId) {
    const el = document.getElementById(elementId);
    el.select();
    navigator.clipboard.writeText(el.value);
    alert("API Key berhasil disalin!");
}
