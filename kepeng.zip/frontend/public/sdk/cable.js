(function() {
    window.KepengCable = {
        publicKey: null,
        init: function(pk) {
            this.publicKey = pk;
        },
        pay: function(params) {
            if (!this.publicKey) {
                return alert("KEPENG Error: Publishable API Key belum diinisialisasi!");
            }

            fetch('/api/cable/initiate', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    api_key: this.publicKey,
                    amount: params.amount,
                    currency: params.currency || 'IDR',
                    recipient_account: params.recipient
                })
            })
            .then(res => res.json())
            .then(data => {
                if(data.success) {
                    const width = 460, height = 680;
                    const left = (screen.width / 2) - (width / 2);
                    const top = (screen.height / 2) - (height / 2);
                    window.open(data.checkout_url, 'KepengGlobalCheckout', `width=${width},height=${height},top=${top},left=${left}`);
                } else {
                    alert("Gagal menghubungkan KEPENG: " + data.error);
                }
            });
        }
    };
})();
